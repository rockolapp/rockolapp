# Sfotipy (Backbone Edition)

Implementación básica de Backbone.js en la aplicación Sfotipy!

## Run

```
$ npm start
```
