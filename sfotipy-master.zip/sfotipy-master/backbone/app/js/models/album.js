Sfotipy.Models.Album = Backbone.Model.extend({});
