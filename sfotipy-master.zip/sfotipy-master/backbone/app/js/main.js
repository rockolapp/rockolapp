$(function() {
  Sfotipy.app = new Sfotipy.Router();
});
