var Sfotipy = {
  Models: {},
  Views: {},
  Collections: {},
  Router: {}
};

window.Sfotipy = Sfotipy;
