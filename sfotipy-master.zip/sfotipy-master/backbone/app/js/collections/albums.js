Sfotipy.Collections.Albums = Backbone.Collection.extend({
  model: Sfotipy.Models.Album
});
