Sfotipy.Collections.Songs = Backbone.Collection.extend({
  model: Sfotipy.Models.Song
});
