sfotipy
=======

El proyecto oficial del curso de Frontend Profesional

Los archivos trabajados en las clases 1, 2 y 3 están en una nueva rama https://github.com/Sfotipy/sfotipy/tree/clases_123

Se libre de contribuir al proyecto terminando el resto del diseño de Sfotipy :)
